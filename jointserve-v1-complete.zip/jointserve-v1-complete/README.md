# JointServe V1

Operator-first B2B field service platform prototype for Dubai.

## Launch wedge
Commercial cleaning for SMEs/property managers, with recurring contracts and multi-location support.

## Prototype routes
- `/` public website
- `/request-quote` lead capture prototype
- `/auth/sign-in` sign-in prototype
- `/dashboard` founder command center
- `/customer` customer portal
- `/technician` mobile field interface

## Production stack
Next.js + TypeScript + Supabase/Postgres/Auth/Storage + Stripe-ready billing + Vercel.

## Run
1. Install Node 20+.
2. `npm install`
3. Copy `.env.example` to `.env.local` and add Supabase values.
4. Run the SQL migration in `supabase/migrations/001_initial_schema.sql`.
5. `npm run dev`
6. Open `http://localhost:3000`.

## Deployment
Deploy the repository to Vercel. Configure the same environment variables in the Vercel project. Add a custom domain after the first successful deployment.

## Important
The current UI is a product prototype. Authentication, server actions, Stripe webhooks, route optimization, email/SMS, and production RLS should be completed and tested before taking live customer payments.
