# JointServe production deployment checklist

1. Create a production Supabase project.
2. Apply `supabase/migrations/001_initial_schema.sql`.
3. Create the current Next.js/Supabase server and browser clients using the official SSR guidance.
4. Add environment variables through the hosting provider's secret store.
5. Create a production Stripe account and products/prices matching Launch/Starter/Growth/Business.
6. Add Stripe webhook endpoint for subscription and payment events.
7. Configure the production domain and DNS.
8. Enable error monitoring, backups, database alerts and uptime monitoring.
9. Test role isolation with Founder, Manager, Technician and Customer accounts.
10. Run a private Dubai pilot before public launch.

Never commit production secrets, Stripe secret keys, service-role keys or database passwords into Git.
