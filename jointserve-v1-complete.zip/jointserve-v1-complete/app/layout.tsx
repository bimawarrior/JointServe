import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'JointServe | B2B Field Service Operations',description:'Professional commercial services managed from one place.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <>{children}</>}
