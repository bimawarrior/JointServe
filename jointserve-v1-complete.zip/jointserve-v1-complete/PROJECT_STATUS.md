# JointServe — Complete V1/V1.5 Build Plan

Launch city: Dubai, UAE
Initial service: Commercial cleaning

## Included in this package
- Public marketing site
- Request Quote lead capture UI
- Sign in UI
- Founder/Admin dashboard
- Customer portal
- Technician mobile workflow
- Local Manager dashboard
- Leads pipeline
- Quotes workflow
- Jobs & scheduling workflow
- Digital playbooks/checklists
- Billing/invoice/subscription screens
- Pricing page
- Settings / organization structure
- Supabase/Postgres schema foundation with RLS
- Production deployment notes
- Full product demo storyboard/video asset

## Production gates
1. Prototype — complete
2. Auth + database wiring — next implementation gate
3. Lead → Quote → Customer → Job — core revenue flow
4. Field execution — playbook, photos, signature
5. Billing — Stripe/webhooks
6. QA/security — production hardening
7. Dubai pilot — first recurring B2B customers
8. Scale — multi-location, managers, new services, SaaS

## Important
This repository is a production-oriented foundation, not a claim that live payment credentials, a live Supabase project, DNS, domain, legal entity, insurance, permits, or production monitoring have already been configured. Those require the founder's real accounts and market-specific setup.
